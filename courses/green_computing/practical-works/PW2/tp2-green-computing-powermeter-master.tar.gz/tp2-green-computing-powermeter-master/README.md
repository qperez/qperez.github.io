# TP2 Green Computing : Création d'un wattmètre logiciel

Les instructions du TP sont dans le Jupyter Notebook `TP2_mesure_conso.ipynb`.